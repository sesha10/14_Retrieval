SEARCH_KEY = "AIzaSyAO-s0XK5prE24cueqD7RYyOTM2VqcZ1N8"
SEARCH_ID = "67402298ae45d495c"
COUNTRY = "in"
SEARCH_URL = "https://www.googleapis.com/customsearch/v1?key={key}&cx={cx}&q={query}&start={start}&gl=" + COUNTRY
RESULT_COUNT = 20